/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller01;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author Colorado
 */
public class Taller01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //INVOCACION
        ejer9();
    }
    /*
    EJERCICIO 1: Programa que lea dos números y muestre la suma,
    resta y residuo de cada uno. (entrada – proceso - salida)
    */
    
    public static void ejer1() {
        Scanner variable=new Scanner(System.in);
        System.out.println("Ingrese el primer numero por favor");
        int num1=variable.nextInt();
        System.out.println("Ingrese el segundo numero por favor");
        int num2=variable.nextInt();
        int suma, resta, residuo;
        
        suma=num1+num2;
        resta=num1-num2;
        
          
        System.out.println("El resultado de la suma es = "+suma);
        System.out.println("El resultado de la resta es = "+resta);
        
         if (num1>num2) {
             residuo=num1%num2;
             System.out.println("El resultado del residuo es = "+residuo);
        } else {
             System.out.println("La operacion no tiene residuo ");
        }
        residuo=num1%num2;
      
        
    }
    /*
    Programa que lea un ser vivo y muestre a cual pertenece.
    Programar 5 posibilidades. ( if )
    */
    public static void ejer2() {
        Scanner variable=new Scanner(System.in);
        
        System.out.println("SELECCIONE UN SER VIVO DE SU PREFERENCIA:");
        System.out.println("camaron\nmanzano\nmoho\nceratium\nmycoplasma");
        
        System.out.println("Digite su ser vivo");
        String ser = variable.nextLine();
    
        if ("camaron".equalsIgnoreCase(ser)) {
            System.out.println("Pertenece al reino Animal");
        } else {
            if ("manzano".equalsIgnoreCase(ser)) {
                System.out.println("Pertenece al reino Vegetal");
            } else {
                if ("moho".equalsIgnoreCase(ser)) {
                    System.out.println("Pertenece al reino Fungi");
                } else {
                    if ("ceratium".equalsIgnoreCase(ser)) {
                        System.out.println("Pertenece al reino Protista");
                    } else {
                        if ("mycoplasma".equalsIgnoreCase(ser)) {
                            System.out.println("Pertenece al reino Monera");
                        } else {
                            System.out.println("INGRESE UN SER DE LA LISTA");
                                  
                        }
                    }
                }
            }
        }
        
    }
    
    public static void ejer3() {
        int a;
        a= Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero en pantalla"));
        JOptionPane.showMessageDialog(null,"el numero seleccionado es "+a);
        
        switch(a){
            case 1:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical DO");
                break;
                
                case 2:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical RE");
                break;
                
                case 3:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical MI");
                break;
                
                case 4:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical FA");
                break;
                
                case 5:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical SOL");
                break;
                
                case 6:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical LA");
                break;
                
                case 7:
                JOptionPane.showMessageDialog(null,"El numero  "+a+ " Representa la nota musical SI");
                break;
                
                default:
                    JOptionPane.showMessageDialog(null,"Ingrese un valor valido");
                break;
        }
    }
    
    public static void ejer4() {
        /*
        Método que lea un valor y muestre los números desde 0
        hasta el valor ingresado ( for )
        */
        int a= Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese un valor limite por favor"));
         JOptionPane.showMessageDialog(null, "La secuencia es ");
        for (int i = 0; i <= a; i++) {
             JOptionPane.showMessageDialog(null, i);
        }
        
         JOptionPane.showMessageDialog(null, "La secuencia ha sido completada");
    }
            
    public static void ejer5() {
        /*
        Método que lea un valor y muestre los números desde 0 hasta el valor ingresado 
        de 3 en 3, para esto reemplace
        en el for el unario i++ por i= i+3.
        */
         int a= Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese un valor limite por favor"));
         JOptionPane.showMessageDialog(null, "La secuencia es ");
        for (int i = 0; i <= a; i+=3) {
             JOptionPane.showMessageDialog(null, i);
        }
        
         JOptionPane.showMessageDialog(null, "La secuencia ha sido completada");
        
    }
    
    public static void ejer6() {
        
        int a=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese un numero por favor"));
        
        if ((a%2)==0) {
            JOptionPane.showMessageDialog(null, "El numero ingresado es Par");
        } else {
             JOptionPane.showMessageDialog(null, "El numero ingresado es Impar");
        }
         
    }
    
    public static void ejer7() {
        int a=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el numero limite por favor"));
        int sumador=0;
        int valor1=1;
        int valor2=0;
        
        while (sumador<=a) {      
            
              JOptionPane.showMessageDialog(null, "La secuencia va en "+ sumador);
            sumador=valor1+valor2;
            valor1=valor2;
            valor2=sumador;
           
            
        }
      }
    
    public static void ejer8() {
     
     int contraseña=22;
     int contador=0;
     
        while (contador<3) {   
            int a=Integer.parseInt(JOptionPane.showInputDialog(null,"por favor intente adivinar la clave, Esta cuenta de 2 digitos"));
            if (a==contraseña) {
                JOptionPane.showMessageDialog(null,"Acceso Permitido");
                break;
            } else {
                JOptionPane.showMessageDialog(null,"Acceso Denegado");
               
            }
            contador=contador+1;
         if(contador==3){
                    JOptionPane.showMessageDialog(null,"Clave bloqueada");
                }
        }
         
    }
    
    public static void ejer9() {
            
           for (int i = 306; i < 1000; i+=18) {
            JOptionPane.showMessageDialog(null, i);
               if (i>360) {
                    int adivinansa=Integer.parseInt(JOptionPane.showInputDialog(null,"Intenta adivinar la tabla de multiplicar\n ¿Que tabla es esta?"));
                    if (adivinansa==18) {
                        JOptionPane.showMessageDialog(null, "Eres un Genio, es correcto");
                       break;
                   }
               } 
           
            
            
        }
            
            
            
            
        }
        
    
        
}
